const mongoose = require('mongoose');
const repositorySchema = mongoose.Schema({
    _id:mongoose.Types.ObjectId,
    filledby:String,
    designation:String,
    date:Date,
    projectname:String,
    organization:String,
    projecttype:String,
    teamsize:String,
    duration:String,
    noofuser:String,
    isprojectsuccess:String,
    hardware:String,
    technology:String,
    ResponsibilitiesofConsultant:String,
    ProjectReferenceable:String,
    reportingmanager:String,
    aboutClientBusiness:String,
    projectrequirement:String,
    Problem:String,
    Solution:String,
    Benefit:String,
    bestemployee:String,
    userId:String,
    startDate:String,
    endDate:String
})

module.exports=mongoose.model('Repository',repositorySchema);