const mongoose = require('mongoose');
const userProfile =  mongoose.Schema({
    _id:mongoose.Schema.Types.ObjectId,
    userId:String,
    profile:String,
    count:Number
})
module.exports=mongoose.model('UserProfile',userProfile);