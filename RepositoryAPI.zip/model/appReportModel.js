const mongoose = require('mongoose');
const reportSchema = mongoose.Schema({
    _id:mongoose.Types.ObjectId,
    pptreport:String,
    userid:String,
    projectId:String,
    reportName:String
})

module.exports=mongoose.model('Report',reportSchema);