const mongoose = require('mongoose');
const projectType = mongoose.Schema({
    _id:mongoose.Types.ObjectId,
    type:{type:String,unique: true ,index:true},
   
})

module.exports=mongoose.model('PT',projectType);