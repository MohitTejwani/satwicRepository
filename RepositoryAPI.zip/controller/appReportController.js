'use strict';
const URL="http://localhost:5000/";
const Report = require('../model/appReportModel');
const Joi = require('joi');
const mongoose = require('mongoose');
const multer = require('multer')
const Repository = require('../controller/appRepositoryController')
// ================= PPT Storage ==============================//
var storage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, './reports/');

    },
    filename: function (req, file, callback) {
        console.log(file)
        callback(null, Date.now().toString() + '-' + file.originalname);
    }
});
const upload = multer({
    storage: storage, limets: {
        fileSize: 1024 * 1024 * 50
    }
}).single('pptreport');


// ============= Report Create   ============================================= //

exports.createReport = function (req, res) {
    // Error  Hander
    // const { error } = validation(req.body);
    // if (error) return res.status(404).send({ err: true, messege: error.details[0].messege })
    upload(req, res, function (err) {
        if (err) {
            res.status(410).json({
                messege: "PPT Not Able Get  "+err
            })
        } else {
            console.log(req.file)
            console.log(req.body)
            //  insert data
            const report = new Report({
                _id: new mongoose.Types.ObjectId,
                pptreport: req.file.path,
                userid: req.body.userid,
                projectId: req.body.projectId,
                reportName:req.body.reportName
            })
            report.save().then(rep => {
                res.send(rep);
            }).catch(err => {
                res.send(err);
            })

        }
    })




}

// ============= List All  Report   ============================================= //

exports.ListAllReport = function (req, res) {
    Report.find().then(rep => {
        res.send(rep)
    }).catch(err => {
        res.send(err)
    })
}


// ============= Get Report By ID  ============================================= //

exports.getReportById = function (req, res) {

    console.log(req.params.id)
    Report.findById(req.params.id).then(rep => {
        res.send(rep)
    }).catch(err => {
        res, send(err)
    })
}

// ============= Get Report By User ID  ============================================= //

exports.getReportByUserId = function (req, res) {

    console.log(req.params.id)
  
    Report.find({userid:req.params.id})
    .then(rep => {
        res.send(rep)
    }).catch(err => {
        res.status(410).json({
            messege:"Bad Request Not able to  get Data "+err
        })
    })
}

// ============= Update Report By ID  ============================================= //


exports.updateReportById = function (req, res) {
    const { error } = validation(req.body);
    if (error) return res.status(404).send({ err: true, messege: error.details[0].messege })

    Report.findByIdAndUpdate(req.params.id, req.body).then(rep => {
        res, send(rep);
    }).catch(err => {
        res.send(err);
    })
}


// ============= Delete Report By ID  ============================================= //

exports.deleteById = function (req, res) {
    Report.findByIdAndRemove(req.params.id).then(rep => {
        res.send(rep);
    }).catch(err => {
        res.send(err);
    })
}

// =============  Report Validation ============================================= //


function validation(report) {
    const schema = Joi.object({
        oldestreport: Joi.string().required(),
        oldreport: Joi.string().required(),
        latestreport: Joi.string().required(),
        userid: Joi.required()
    })
    return Joi.validate(report, schema)
}



// 

exports.deleteall = function(req,res){
    Report.remove({}).exec().then(rep=>{
        res.send('delte')
    }).catch(err=>{
        res.send('fail')
    })
}