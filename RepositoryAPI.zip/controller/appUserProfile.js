'use strick'
const userProfile = require('../model/userProfileModel');
const newUser = require('./appUserController')
var multer = require('multer');
const mongoose = require('mongoose');
var storage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, './public/images');
    },
    filename: function (req, file, callback) {
        callback(null, Date.now() + '-' + file.originalname);
    }
});

var upload = multer({ storage: storage }).single('image');


exports.imageUpload = function (req, res) {

    upload(req, res, function (err) {

        if (err) {
            return res.end("Error uploading file.");
        }
        if (req.body.first == "yes") {
            console.log(req.body.first)
            const user = new userProfile({
                _id: new mongoose.Types.ObjectId,
                profile: req.file.path,
                userId: req.params.id,
                first: 'no'
            })
            user.save().then(rep => {
                res.send(rep)
            }).catch(err => {
                res.send(err);
            })
        } else {
            console.log(req.file)
            console.log(req.body.first)
            userProfile.findOne({ userId: req.params.id }).then(rep => {
                res.send(rep)
            }).catch(err => {
                res.send(err)
            })
        }




    });
}