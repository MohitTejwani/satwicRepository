'use strict';
const PT = require('../model/appProjectTpyeModel');
const mongoose = require('mongoose');


//==============================  Get All User Details ===========================// 
exports.list_all_ProjectType = function (req, res) {
  PT.find().then(rep => {
    res.send(rep)
  }).catch(err => {
    res.status(500).send(err)
  })

};

// =========================== Create New User ===========================//
exports.create_a_ProjectType = function (req, res) {


  PT.find({ type: req.body.type }).exec().then(rep => {
    if (rep.length > 0) {
      res.status(210).json({
        messege: " Project type is already Exist"
      })
    } else {
      var new_user = new PT({
        _id: new mongoose.Types.ObjectId,
        type: req.body.type
      });


      new_user.save().then(rep => {
        res.send(rep)
      }).catch(err => {
        res.send(err)
      })

    }
  })


};

