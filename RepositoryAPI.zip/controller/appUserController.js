'use strict';
const URL = "http://localhost:5000/";
var User = require('../model/appUserModel');
const mongoose = require('mongoose');
const Joi = require('joi');
const validator = require('express-joi-validation').createValidator({})
const nodemailer = require('nodemailer');
const multer = require('multer');
// ================= Image Storage ==============================//
var storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, './uploads/');

  },
  filename: function (req, file, callback) {
    console.log(file)
    callback(null, Date.now().toString() + '-' + file.originalname);
  }
});

const upload = multer({
  storage: storage, limets: {
    fileSize: 1024 * 1024 * 5
  }
}).single('profileImage');

//==============================  Get All User Details ===========================// 
exports.list_all_user = function (req, res) {
  const user = User.find().then(rep => {
    res.send(rep)
  }).catch(err => {
    res.status(500).send(err)
  })

};

// =========================== Create New User ===========================//
exports.create_a_user = function (req, res) {


  var new_user = new User({
    _id: new mongoose.Types.ObjectId,
    name: req.body.name,
    email: req.body.email,
    contact: req.body.contact,
    password: req.body.password,
    first: true,
    porfileImage: null
  });

  new_user.save().then(rep => {
    res.send(rep)
  }).catch(err => {
    res.send(err)
  })


};

// =========================== get User By ID ===========================//
exports.getUserById = function (req, res) {
  User.findById(req.params.id).then(rep => {
    res.send(rep);
  }).catch(err => {
    res.send(err);
  })
}
//=========================== Update User By ID ===========================//
exports.updateUserById = function (req, res) {

  User.findByIdAndUpdate(req.params.id, req.body).then(rep => {
    res.send(rep);
  }).catch(err => {
    res.send(err);
  })
}
//=========================== Delete User By ID ===========================//
exports.deleteById = function (req, res) {
  User.findByIdAndRemove(req.params.id, req.body).then(rep => {
    res.send(rep);
  }).catch(err => {
    res.send(err);
  })
}

// =========================== Login User  ===========================//
exports.userVerify = function (req, res) {
  User.findOne({ email: req.body.email, password: req.body.password }).then(rep => {
    res.send(rep)
  }).catch(err => {
    res.send(err)
  })
}
// =========================== Image Update Or Upload ===========================//
exports.imageUpload = function (req, res) {
  upload(req, res, function (err) {
    console.log(req.body)
    if (err) {
      res.status(401).json({
        message: "Not Able get Request"+err
      })
    } else {
      User.findByIdAndUpdate(req.params.id, {
              porfileImage: req.file.path,
              first: false
            }).then(rep => {
              res.send(rep);
            }).catch(err => {
              res.send(err);
            })
          }
      
    
  })

  // upload(req, res, function (err) {
  //   console.log(req.file)
  //   if (err) {
  //     return res.status(401).json({
  //       message: "invalid Profile Image"
  //     })
  //   } else {
  //     //handles null error 
  //     console.log(req.file.path)
  //     User.findByIdAndUpdate(req.params.id, {
  //       porfileImage: req.file.path,
  //       first: false
  //     }).then(rep => {
  //       res.send(rep);
  //     }).catch(err => {
  //       res.send(err);
  //     })
  //   }
  // })
}

//=========================== Sending Email to User contact Number ===========================//
exports.sendUserEmail = function (req, res) {

  User.findOne({ email: req.body.email }).then(rep => {

    var transport = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "tejwanimohit11@gmail.com",
        pass: "9687381053m"
      }
    });
    var maiilOption = {
      from: "tejwanimohit11@gmail.com",
      to: rep.email,
      subject: "Test Email Forget Password",
      text: "Hello " + rep.name + "  your new Password is 12345"
      //html: '<h1>Welcome</h1><p>That was easy!</p>'
    };
    transport.sendMail(maiilOption, function (err, info) {
      if (err)
        res.send(err)
      else
        res.send({ message: "sended email" + info.response })

    })


  }).catch(err => {
    res.send(err)
  })



}

// =========================== User Login  ===========================//
exports.loginUser = function(req,res){
  console.log(req.body.email)
    User.findOne({email:req.body.email})
    .exec()
    .then(rep=>{
      res.status(200)
        .json({
          message:"Login Successfull",
          id:rep._id
        })
    })
    .catch(err=>{
      res.status(200)
      .json({
        message:"Invalid User"
      })
    })
}


// =========================== User Validation ===========================//
function validation(userData) {
  const schema = Joi.object({
    name: Joi.string().min(3).max(30).required(),
    email: Joi.string().required(),
    contact: Joi.string().min(10).max(10).required(),
    password: Joi.string().min(6).required()

  })
  return Joi.validate(userData, schema);
}


// 
exports.deleteall =function(req,res){
  User.remove({}).exec()
    .then(rep=>{
        res.send('delete')
    }).catch(err=>{
      res.send(err)
    })
}