'use Strict'
const mongoose = require('mongoose');
const Repository = require('../model/appRepositoryModel');
const Joi = require('joi');
var multer = require('multer');
mongoose.set('useFindAndModify', false)

// ============= List All Porject   ============================================= //

exports.listRepository = function (req, res) {
    Repository.find().then(rep => {
        res.send(rep)
    }).catch(err => {
        res.send(err)
    })
}

// ============= Porject Create  ============================================= //

exports.createRepository = function (req, res) {
    // Error Hander

    const repo = new Repository({
        _id: new mongoose.Types.ObjectId,
        filledby: req.body.filledby,
        designation: req.body.designation,
        date: Date.now(),
        projectname: req.body.projectname,
        organization: req.body.organization,
        projecttype: req.body.projecttype,
        teamsize: req.body.teamsize,
        duration: req.body.duration,
        noofuser: req.body.noofuser,
        isprojectsuccess: req.body.isprojectsuccess,
        hardware: req.body.hardware,
        technology: req.body.technology,
        ResponsibilitiesofConsultant: req.body.ResponsibilitiesofConsultant,
        ProjectReferenceable: req.body.ProjectReferenceable,
        reportingmanager: req.body.reportingmanager,
        aboutClientBusiness: req.body.aboutClientBusiness,
        projectrequirement: req.body.projectrequirement,
        Problem: req.body.Problem,
        Solution: req.body.Solution,
        Benefit: req.body.Benefit,
        bestemployee: req.body.bestemployee,
        userId: req.body.userId,
        startDate: req.body.startDate,
        endDate: req.body.endDate
    })

    repo.save().then(rep => { res.send(rep) }).catch(err => { res.send(err) })

}

// ============= Get Porject By User  ID  ============================================= //

exports.getRepositoryById = function (req, res) {
    console.log(req.params.id)
    Repository.find({ userId: req.params.id }).then(rep => { res.send(rep) }).catch(err => { res.send(err) })
}

// ============= Get Porject By ID  ============================================= //

exports.getSingleRepositoryById = function (req, res) {
    console.log(req.params.id)

    Repository.findOne({ _id: req.params.id }).then(rep => { res.send(rep) }).catch(err => { res.send(err) })
}

// ============= Udate Porject By ID  ============================================= //

exports.updateRepositoryById = function (req, res) {
    Repository.findByIdAndUpdate(req.params.id, req.body).exec().then(rep => {
        res.status(201).json({
            messege: "updated Succesfully"
        })
    }).catch(err => {
        res.status(401).json({
            messege: "Bad Request" + err
        })
    })
}

// ============= Delete Porject By ID  ============================================= //

exports.deleteRepositoryById = function (req, res) {
    Repository.findByIdAndRemove(req.params.id).then(rep => { res.send(rep) }).catch(err => { res.send(err) })
}

// ============= Image Upload  ============================================= //

function imageUpload() {
    const storage = multer.diskStorage({
        destination: (req, file, callback) => {
            callback(null, '../public/images');
        },
        filename: (req, file, callback) => {
            callback(null, Date.now() + '-' + file.originalname);
        }
    });

    const upload = multer({ storage: storage }).any('file');

    upload(req, res, (err) => {
        if (err) {
            return false
        }
        let results = req.files.map((file) => {
            return {
                mediaName: file.filename,
                origMediaName: file.originalname,
                mediaSource: 'https://' + req.headers.host + '/public/images' + file.filename
            }
        });
        return true
    });
}

// ============= Create Incomplete Project By UserID  ============================================= //


exports.incompleteRepository = function (req, res) {
    console.log(req.params.id)

    Repository.findOne({ userId: req.params.id, complete: "false" })
        .exec()
        .then(rep => {
            res.status(201).json({
                response: rep
            })
        }).catch(err => {
            res.status(410).json({
                messege: err
            })
        })
}


exports.deleteall = function(req,res){
    Repository.remove({}).exec().then(rep=>{
        res.send('delte')
    }).catch(err=>{
        res.send('fail')
    })
}