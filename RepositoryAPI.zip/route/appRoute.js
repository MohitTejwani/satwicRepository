'use strict';
module.exports = function (app) {
  const User = require('../controller/appUserController');
  const Report = require('../controller/appReportController');
  const Repositpory = require('../controller/appRepositoryController')
  const userProfile = require('../controller/appUserProfile');
  const PT = require('../controller/appProjectypeConroller');

  app.route('/deletealluser')
    .delete(User.deleteall);
  app.route('/deleteallrepository')
    .delete(Repositpory.deleteall)
  app.route('/deleteallreports')
    .delete(Report.deleteall)

  // ============= User Routes============================================= //
  app.route('/users')
    .get(User.list_all_user)
    .post(User.create_a_user);

  app.route('/user/:id')
    .get(User.getUserById)
    .put(User.updateUserById)
    .delete(User.deleteById);
  app.route('/userLogin')
    .post(User.userVerify);

  app.route('/userVerify')
    .post(User.loginUser)
  // user profile Image Upload
  app.route('/Upload/:id')
    .put(userProfile.imageUpload);

  app.route('/profileupload/:id')
    .put(User.imageUpload);

  // ============= Reports Routes ============================================= // 
  app.route('/reports')
    .get(Report.ListAllReport)
    .post(Report.createReport);
  app.route('/report/:id')
    .get(Report.getReportById)
    .put(Report.updateReportById)
    .delete(Report.deleteById);
  app.route('/getUserReport/:id')
    .get(Report.getReportByUserId)

  // ============= Repository / Projects  Routes ============================================= //
  app.route('/repositporys')
    .get(Repositpory.listRepository)
    .post(Repositpory.createRepository);

  app.route('/repositpory/:id')
    .get(Repositpory.getRepositoryById)
    .put(Repositpory.updateRepositoryById)
    .delete(Repositpory.deleteRepositoryById);
  app.route('/incompleteRepository/:id')
    .get(Repositpory.incompleteRepository)

  app.route('/singleRepository/:id')
    .get(Repositpory.getSingleRepositoryById);

  // ============= project Type  Routes============================================= //
  app.route('/getprojecttype')
    .get(PT.list_all_ProjectType)
    .post(PT.create_a_ProjectType);
  // ============= Others  Routes============================================= //

  // Forget Password 
  app.route('forgetpassword')
    .get(User.sendUserEmail)
  // default route
  app.get('/', function (req, res) {
    return res.send({ error: true, message: 'hello satwic' })
  });

  app.use((req, res, next) => {
    const error = new Error("Not Found");
    error.status = 404;
    next(error);
  })

  app.use((error, req, res, next) => {
    res.status(error.status || 500);
    res.json({
      error: {
        message: error.message
      }
    })
  })

}