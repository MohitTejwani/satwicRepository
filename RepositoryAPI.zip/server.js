var express = require('express');
var app = express();
const morgan = require('morgan')
bodyParser = require('body-parser');
port = process.env.PORT || 5000;
require('dotenv/config')
var cors = require('cors')

const uri = "mongodb+srv://SatWic:3AIuKXmaOPsgWOkF@cluster0-ngz2s.mongodb.net/test?retryWrites=true&w=majority";

const mongoose = require('mongoose');
mongoose.connect(uri,
    { useNewUrlParser: true },
    ()=>console.log("conntext to db"));



app.use(cors())
app.use('/uploads',express.static('uploads'));
app.use('/reports',express.static('reports'));


// Header request
app.use(function(req, res, next) {
    // res.header("Access-Control-Allow-Origin", "*");
    //res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
	    
	 // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');
    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
  });
app.use(morgan('dev'))
app.listen(port);

console.log('API server started on: ' + port);

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


var routes = require('./route/appRoute'); //importing route
routes(app); //register the route
